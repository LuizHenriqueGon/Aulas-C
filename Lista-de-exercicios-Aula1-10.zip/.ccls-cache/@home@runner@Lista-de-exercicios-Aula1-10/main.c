#include <stdio.h>
//Escrever um programa que lê a identificação de um vendedor (a identificação pode ser um número inteiro qualquer), o seu salário fixo, o total das vendas por ele efetuadas e o percentual que ganha sobre o total de vendas. O programa deve calcular o salário total do vendedor e apresentar na tela a identificação do vendedor e o seu salário total.
int main(void) {
  int Nome;
  float SalarioFixo, TotalVendas, Percentual, SalarioTotal;
  printf("Digite o numero de indetificação do vendedor: ");
  scanf("%d",&Nome);
  printf("Digite o salario fixo: ");
  scanf("%f",&SalarioFixo);
  printf("Digite o total de vendas: ");
  scanf("%f", &TotalVendas);
  printf("Digite o percentual sobre o total de vendas: ");
  scanf("%f",&Percentual);
  SalarioTotal = SalarioFixo + (TotalVendas * Percentual);
  printf("O salario total do vendedor %d é de: %.2f", Nome, SalarioTotal);
  return 0;
}