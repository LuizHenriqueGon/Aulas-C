#include <stdio.h>
/*Escreva um programa que receba três números inteiros e positivos (A, B, C) e
calcule a seguinte expressão:
D = (R + S) / 2
Sendo R = (A + B)2 e S = (B + C) 2.
Dica: para o cálculo do quadrado, neste momento, use x * x.*/
int main(void) {
  int A, B, C;
  int R, S;
  float D;
  printf("Digite o valor de A: ");
  scanf("%d",&A);
  printf("Digite o valor de B: ");
  scanf("%d", &B);
  printf("Digite o valor de C: ");
  scanf("%d", &C);
  R = (A + B) * (A + B);
  S = (B + C) * (B + C);
  D = (R + S) / 2;
  printf("O valor de D é: %.2f", D);
  return 0;
}